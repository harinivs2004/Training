package com.wipro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppverseAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
